<?php
    namespace Src\AdminController;

    echo "Admin Controller";
    exit;

?>