<?php
    namespace Src\UsersController;

    echo "b";
    exit;

?>