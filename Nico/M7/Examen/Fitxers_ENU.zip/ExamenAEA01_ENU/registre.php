<?php


// Comprovació si el formulari s'ha enviat


// Validació de camps buits i registre d'usuari

// Missatge d'èxit o error
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <title>Registre de Nou Usuari</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .contingut { width: 300px; margin: 50px auto; padding: 20px; border: 1px solid #ccc; }
    </style>
</head>
<body>
    <div class="contingut">
        <h1>Registre d'Usuaris</h1>
        
        <?php /*Mostrar missatge*/ ?>

        <form method="POST" action="<?php /*Redirigeix sobre si mateix*/ ?>">
            <label for="usuari">Nom d'Usuari:</label><br>
            <input type="text" id="usuari" name="usuari" required><br><br>
            
            <label for="contrasenya">Contrasenya:</label><br>
            <input type="password" id="contrasenya" name="contrasenya" required><br><br>
            
            <button type="submit">Registrar</button>
        </form>
        
        <p>Ja tens un compte? <a href="inici.php">Inicia sessió</a></p>
    </div>
</body>
</html>